package com.example.context_service;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ContextServiceApplicationTests {

	@Test
	void contextLoads() {
	}

}
