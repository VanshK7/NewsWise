package com.example.context_service.controller;

import com.example.context_service.service.ContextService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/context")
public class ContextController {

    private final ContextService contextService;

    @Autowired
    public ContextController(ContextService contextService) {
        this.contextService = contextService;
    }

    @PostMapping("/generate")
    public String generateResponse(@RequestBody String message) {
        return contextService.generateResponse(message);
    }

    @PostMapping("/summarize")
    public String summarizeArticle(@RequestBody String article) {
        return contextService.summarizeArticle(article);
    }

    @PostMapping("/topic")
    public String getTopic(@RequestBody String article) {
        return contextService.getTopic(article);
    }
}