package com.example.recommendation.service;

import com.example.recommendation.client.UserServiceClient;
import com.example.recommendation.model.Article;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.stream.Collectors;

@Service
public class RecommendationService {

    private final UserServiceClient userServiceClient;

    // Hardcoded articles.csv data (can be moved to a file if needed)
    private static final List<Article> ARTICLES = List.of(
            new Article("101", "Technology|AI", "New advancements in AI and machine learning."),
            new Article("102", "Sports|Football", "Latest football match results and highlights."),
            new Article("103", "Politics|Elections", "Upcoming elections and candidate analysis."),
            new Article("104", "Health|Wellness", "10 tips to stay fit and healthy."),
            new Article("105", "Technology|Programming", "Best programming languages to learn in 2025."),
            new Article("106", "Sports|Cricket", "India vs Australia match review."),
            new Article("107", "Space|Astronomy", "NASA's latest Mars rover mission update."),
            new Article("108", "Government|Policies", "New economic policies announced by the government."),
            new Article("109", "Fitness|Health", "How to maintain a good diet and workout plan.")
    );

    public RecommendationService(UserServiceClient userServiceClient) {
        this.userServiceClient = userServiceClient;
    }

    // Fetch the user's preferences from UserService microservice
    public String getUserPreference(Long userId) {
        return userServiceClient.getUserInterest(userId);
    }

    // Get articles that match the user's preferences
    public List<Article> getMatchingArticles(Long userId) {
        // Fetch user preferences from UserService
        String userInterest = userServiceClient.getUserInterest(userId);

        if (userInterest == null || userInterest.isEmpty()) {
            return List.of(); // Return empty list if no preferences found
        }

        // Split preferences if separated by "|"
        List<String> preferences = List.of(userInterest.split("\\|"));

        // Filter articles that match the user interests
        return ARTICLES.stream()
                .filter(article -> preferences.stream().anyMatch(article.getCategory()::contains))
                .collect(Collectors.toList());
    }
}
