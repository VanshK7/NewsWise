package com.example.recommendation.model;

import java.util.List;

public class User {
    private String userId;
    private List<String> preferences;

    public User(String userId, List<String> preferences) {
        this.userId = userId;
        this.preferences = preferences;
    }

    public String getUserId() {
        return userId;
    }

    public List<String> getPreferences() {
        return preferences;
    }
}
