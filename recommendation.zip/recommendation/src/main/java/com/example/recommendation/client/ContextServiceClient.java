package com.example.recommendation.client;

import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;

@FeignClient(name = "context-service", url = "http://localhost:8082")
public interface ContextServiceClient {

    @PostMapping("/api/llm/extract")
    String analyzeArticle(@RequestBody String articleText);
}