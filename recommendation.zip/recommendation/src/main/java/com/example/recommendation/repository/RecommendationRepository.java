package com.example.recommendation.repository;

public interface RecommendationRepository {
}
