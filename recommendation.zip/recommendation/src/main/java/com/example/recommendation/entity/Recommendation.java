package com.example.recommendation.entity;

public class Recommendation {
}
