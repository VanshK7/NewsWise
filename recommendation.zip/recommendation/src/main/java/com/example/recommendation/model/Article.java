package com.example.recommendation.model;

public class Article {
    private String id;
    private String category;
    private String content;

    public Article(String id, String category, String content) {
        this.id = id;
        this.category = category;
        this.content = content;
    }

    public String getId() { return id; }
    public String getCategory() { return category; }
    public String getContent() { return content; }
}
