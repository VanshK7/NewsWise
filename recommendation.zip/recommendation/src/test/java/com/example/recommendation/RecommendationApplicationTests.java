package com.example.recommendation;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class RecommendationApplicationTests {

	@Test
	void contextLoads() {
	}

}
